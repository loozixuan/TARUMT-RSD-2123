<?php

require_once 'Account.php';

class SAXParser {

    private $accounts; // list of Employee objects
    private $filename;
    private $accountTmp; // Employee object
    private $tmpValue;

    public function __construct($filename) {
        $this->filename = $filename;
        $this->accounts = array();
        $this->parseDocument();
        $this->printData();
    }

    public function startElement($parser, $name, $attr) {
        if (!empty($name)) {
            if ($name == 'ACCOUNT') {
                $this->accountTmp = new Account();
            }
        }
    }

    public function endElement($parser, $name) {
        if ($name == 'ACCOUNT') {
            $this->accounts[] = $this->accountTmp;
        } elseif ($name == 'NUMBER') {
            $this->accountTmp->setNumber($this->tmpValue);
        } elseif ($name == 'BALANCE') {
            $this->accountTmp->setBalance($this->tmpValue);
        }
    }

    public function characters($parser, $data) {
        if (!empty($data)) {
            $this->tmpValue = trim($data);
        }
    }

    private function parseDocument() {
        $parser = xml_parser_create();
        xml_set_element_handler($parser,
                array($this, "startElement"),
                array($this, "endElement"));

        xml_set_character_data_handler($parser, array($this, "characters"));

        if (!($handle = fopen($this->filename, "r"))) {
            die("could not open XML input");
        }

        while ($data = fread($handle, 4096)) {
            xml_parse($parser, $data);
        }
    }

    public function printData() {
        $totalBalance = 0;
        foreach ($this->accounts as $acc) {
            $totalBalance += $acc->getBalance();
            print $acc . "<br />";
        }
        print $totalBalance . "<br />";
    }

}

$worker = new SAXParser("Account.xml");
?>

