<?php

require_once 'Account.php';

class DOMParser {

    private $accounts;

    public function __construct($filename) {
        $this->accounts = new SplObjectStorage();
        $this->readFromXML($filename);
        $this->display();
    }

    public function readFromXML($filename) {
        $xml = simplexml_load_file($filename);
        $accList = $xml->account; // retrieve all the account nodes

        foreach ($accList as $acc) {
            $attr = $acc->attributes();
            $accTemp = new Account(
                    $acc->number,
                    $acc->balance
            );

            $this->accounts->attach($accTemp);
        }
    }

    public function display() {
        echo "<h2>Account Listing </h2>";
        foreach ($this->accounts as $acc) {
            print $acc . "<br />";
        }
    }

}

$worker = new DOMParser("Account.xml");
?>
