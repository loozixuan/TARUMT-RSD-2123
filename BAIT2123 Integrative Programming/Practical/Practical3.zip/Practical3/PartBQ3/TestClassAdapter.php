<?php
require_once 'TemperatureClassAdapter.php';
?>

<html>
    <head>
        <title>Temperature Monitoring Application</title>
    </head>
    <body>
        <?php
        $f = 37;
        $classAdapter = new TemperatureClassAdapter();
        $classAdapter->setTemperatureInF($f);

        echo "Temperature in Farenheit : " . number_format($classAdapter->getTemperatureInF(), 2) . "<br/>" .
        "Temperature in Celcius : " . number_format($classAdapter->getTemperatureInC(), 2) . "<br/>";

        $c = 2.7;
        $classAdapter->setTemperatureInC($c);
        echo "Temperature in Farenheit : " . number_format($classAdapter->getTemperatureInF(), 2) . "<br/>" .
        "Temperature in Celcius : " . number_format($classAdapter->getTemperatureInC(), 2) . "<br/>";
        ?>
    </body>
</html>