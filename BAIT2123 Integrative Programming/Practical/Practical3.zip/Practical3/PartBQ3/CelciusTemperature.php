<?php

class CelciusTemperature {

    private $temperatureInC;

    function getTemperatureInC() {
        return $this->temperatureInC;
    }

    function setTemperatureInC($temperatureInC) {
        $this->temperatureInC = $temperatureInC;
    }

}
