<?php
require_once 'TemperatureObjectAdapter.php';
?>

<html>
    <head>
        <title>Temperature Monitoring Application</title>
    </head>
    <body>
        <?php
        $f = 47;
        $objectAdapter = new TemperatureObjectAdapter();
        $objectAdapter->setTemperatureInF($f);

        echo "Temperature in Farenheit : " . number_format($objectAdapter->getTemperatureInF(), 2) . "<br/>" .
        "Temperature in Celcius : " . number_format($objectAdapter->getTemperatureInC(), 2) . "<br/>";

        $c = 2.7;
        $objectAdapter->setTemperatureInC($c);
        echo "Temperature in Farenheit : " . number_format($objectAdapter->getTemperatureInF(), 2) . "<br/>" .
        "Temperature in Celcius : " . number_format($objectAdapter->getTemperatureInC(), 2) . "<br/>";
        ?>
    </body>
</html>