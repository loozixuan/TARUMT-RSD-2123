<?php

require_once 'ITemperature.php';
require_once 'CelciusTemperature.php';

class TemperatureObjectAdapter implements ITemperature {

    private $celciusTemperature;

    public function __construct() {
        $this->celciusTemperature = new CelciusTemperature();
    }

    public function getTemperatureInC() {
        return $this->celciusTemperature->getTemperatureInC();
    }

    public function getTemperatureInF() {
        $celcius = $this->celciusTemperature->getTemperatureInC();
        return $celcius * (9 / 5) + 32;
    }

    public function setTemperatureInC($temperatureInC) {
        $this->celciusTemperature->setTemperatureInC($temperatureInC);
    }

    public function setTemperatureInF($temperatureInF) {
        $celcius = ($temperatureInF - 32) * (5 / 9);
        $this->celciusTemperature->setTemperatureInC($celcius);
    }

}
