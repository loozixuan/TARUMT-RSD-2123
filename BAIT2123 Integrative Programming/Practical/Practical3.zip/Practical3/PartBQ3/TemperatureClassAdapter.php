<?php

require_once 'ITemperature.php';
require_once 'CelciusTemperature.php';

class TemperatureClassAdapter extends CelciusTemperature implements ITemperature {

    public function getTemperatureInF() {
        $celcius = $this->getTemperatureInC();
        return $celcius * (9 / 5) + 32;
    }

    public function setTemperatureInF($temperatureInF) {
        $celcius = ($temperatureInF - 32) * (5 / 9);
        $this->setTemperatureInC($celcius);
    }

}
