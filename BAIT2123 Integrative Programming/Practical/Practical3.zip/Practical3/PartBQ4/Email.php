<?php

require_once 'IEmail.php';

class Email implements IEmail {

    private $to;
    private $from;
    private $message;

    function __construct($to, $from, $message) {
        $this->to = $to;
        $this->from = $from;
        $this->message = $message;
    }

    function getTo() {
        return $this->to;
    }

    function getFrom() {
        return $this->from;
    }

    function getMessage() {
        return $this->message;
    }

    public function getContent() {
        return $this->message;
    }

}
