<?php
require_once 'Email.php';
require_once 'DisclaimerDecorator.php';
require_once 'SecureEmailDecorator.php';
?>

<html>
    <head>
        <title>Decorator</title>
    </head>
    <body>
        <?php
        $email = new Email("abc@gmail.com", "xyk@gmail.com", "Hello World");
        $disEmail = new DisclaimerDecorator($email);

        echo "Original Email : " . $email->getContent() . "<br/><br/>";
        echo "Disclaimer Email (with) : " . $disEmail->getContent() . "<br/><br/>";

        $enEmail = new SecureEmailDecorator($email);
        echo "Encrypted Email (with) : " . $enEmail->getContent();
        echo $disEmail->getDisclaimerMsg();
        ?>
    </body>
</html>