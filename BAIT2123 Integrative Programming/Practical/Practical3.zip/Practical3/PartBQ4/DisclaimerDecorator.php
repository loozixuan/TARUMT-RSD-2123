<?php

require_once 'AbstractDecorator.php';

class DisclaimerDecorator extends AbstractDecorator {

    private $disclaimerMsg = "<i>This message is confidential</i>";

    public function __construct($email) {
        parent::__construct($email);
    }

    public function getContent() {
        return $this->email->getContent() . "<br/>" . $this->getDisclaimerMsg();
    }

    public function getDisclaimerMsg() {
        return $this->disclaimerMsg;
    }

}
