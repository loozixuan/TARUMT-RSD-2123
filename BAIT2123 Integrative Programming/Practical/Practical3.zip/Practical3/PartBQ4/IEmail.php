<?php

interface IEmail {

    public function getContent();
}
