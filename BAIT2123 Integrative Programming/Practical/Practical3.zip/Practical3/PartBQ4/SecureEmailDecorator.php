<?php

require_once 'AbstractDecorator.php';

class SecureEmailDecorator extends AbstractDecorator {

    public function __construct($email) {
        parent::__construct($email);
    }

    public function getContent() {
        return $this->encryption() . "<br/>";
    }

    public function encryption() {
        return str_shuffle($this->email->getContent());
    }

}
