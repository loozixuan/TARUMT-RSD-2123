<?php

require_once 'IEmail.php';

abstract class AbstractDecorator implements IEmail {

    protected $email;

    function __construct($email) {
        $this->email = $email;
    }

    public abstract function getContent();
}
