<?php
require_once 'WeatherData.php';
require_once 'CurrentCondition.php';
require_once 'WeatherStatistic.php';
require_once 'SimpleForecast.php';
?>

<html>
    <head>
        <title>Weather Monitoring Application Using SqlObserver, SqlSubject</title>
    </head>

    <body>
        <h2>Real Time Weather Records from Weather Station</h2>
        <?php
        $w = new WeatherData(33, 44, 55);
        echo "<h4>Initial Weather Reading in the station</h4>";
        echo "Temperature : " . $w->getTemperature() . "&#8451; <br/>";
        echo "Humidity : " . $w->getHumidity() . "% <br/>";
        echo "Pressure : " . $w->getPressure() . "Pa <br/>";

        // Test Current Condition
        $c = new CurrentCondition($w);
        $w->attach($c);

        // Test Weather Statistic
        $s = new WeatherStatistic($w);
        $w->attach($s);

        // Test Simple Forecast
        $f = new SimpleForecast($w);
        $w->attach($f);

        $w->setTemperature(99);
        $w->setTemperature(88);
        $w->setPressure(88);
        $w->setPressure(12);
        ?>
    </body> 
</html>
