<?php

class WeatherData implements SplSubject {

    private $temperature;
    private $humidity;
    private $pressure;

    public function __construct($temperature = 0, $humidity = 0, $pressure = 0) {
        $this->observers = new SplObjectStorage();
        $this->temperature = $temperature;
        $this->humidity = $humidity;
        $this->pressure = $pressure;
    }

    function getTemperature() {
        return $this->temperature;
    }

    function getHumidity() {
        return $this->humidity;
    }

    function getPressure() {
        return $this->pressure;
    }

    function setTemperature($temperature) {
        $this->temperature = $temperature;
        $this->notify();
    }

    function setHumidity($humidity) {
        $this->humidity = $humidity;
        $this->notify();
    }

    function setPressure($pressure) {
        $this->pressure = $pressure;
        $this->notify();
    }

    public function attach(\SplObserver $observer): void {
        $this->observers->attach($observer);
    }

    public function detach(\SplObserver $observer): void {
        $index = 0; // use it as the offset which we want to delete
        foreach ($this->observers as $o) {
            if ($o == $observer) {
                array_splice($this->observers, $index);
            }
            $index++;
        }
    }

    public function notify(): void {
        foreach ($this->observers as $o) {
            $o->update($this);
        }
    }

}
