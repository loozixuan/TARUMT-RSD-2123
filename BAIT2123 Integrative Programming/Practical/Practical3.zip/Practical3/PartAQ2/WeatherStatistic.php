<?php

require_once 'WeatherData.php';
require_once 'DisplayElements.php';

class WeatherStatistic implements SplObserver, DisplayElements {

    private $minTemp;
    private $maxTemp;
    private $avgTemp;

    public function __construct(WeatherData $w) {
        $this->avgTemp = $w->getTemperature();
        $this->maxTemp = PHP_FLOAT_MIN; // -999
        $this->minTemp = PHP_FLOAT_MAX; // 999
    }

    public function update(\SplSubject $subject): void {
        $currentTemp = $subject->getTemperature();

        if ($currentTemp < $this->minTemp) {
            $this->minTemp = $currentTemp;
        }

        if ($currentTemp > $this->maxTemp) {
            $this->maxTemp = $currentTemp;
        }

        $this->avgTemp = ($this->maxTemp + $this->minTemp) / 2;
        $this->display();
    }

    public function display() {
        $msg = "<br/><b>Weather Statistics </b><br/>";
        $msg .= "Minimum Temperature :" . $this->minTemp . "&#8451;<br/>";
        $msg .= "Maximum Temperature : " . $this->maxTemp . "&#8451;<br/>";
        $msg .= "Average Temperature : " . $this->avgTemp . "&#8451;<br/>";

        echo $msg;
    }

}
