<?php

interface DisplayElements {

    public function display();
}
