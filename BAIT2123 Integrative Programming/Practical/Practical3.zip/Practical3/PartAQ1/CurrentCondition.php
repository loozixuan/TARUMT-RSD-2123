<?php

require_once 'Observer.php';
require_once 'Subject.php';
require_once 'WeatherData.php';
require_once 'DisplayElements.php';

class CurrentCondition implements Observer, DisplayElements {

    private $temp;
    private $humidity;

    public function __construct(WeatherData $w) {
        $this->temp = $w->getTemperature();
        $this->humidity = $w->getHumidity();
    }

    public function Update(Subject $subject) {
        $this->temp = $subject->getTemperature();
        $this->humidity = $subject->getHumidity();
        $this->display();
    }

    public function display() {
        $msg = "<br/><b>Current Condition</b><br/>";
        $msg .= "Temperature :" . $this->temp . "&#8451;<br/>";
        $msg .= "Humidity: " . $this->humidity . "%<br/>";

        echo $msg;
    }

}
