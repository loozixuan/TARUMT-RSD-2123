<?php

require_once 'Subject.php';
require_once 'Observer.php';

class WeatherData implements Subject {

    private $observers;
    private $temperature;
    private $humidity;
    private $pressure;

    public function __construct($temperature = 0, $humidity = 0, $pressure = 0) {
        $this->observers = array();
        $this->temperature = $temperature;
        $this->humidity = $humidity;
        $this->pressure = $pressure;
    }

    function getTemperature() {
        return $this->temperature;
    }

    function getHumidity() {
        return $this->humidity;
    }

    function getPressure() {
        return $this->pressure;
    }

    function setTemperature($temperature) {
        $this->temperature = $temperature;
        $this->notifyObserver();
    }

    function setHumidity($humidity) {
        $this->humidity = $humidity;
        $this->notifyObserver();
    }

    function setPressure($pressure) {
        $this->pressure = $pressure;
        $this->notifyObserver();
    }

    public function attachObserver(Observer $observer) {
        array_push($this->observers, $observer);
    }

    public function detachObserver(Observer $observer) {
        $index = 0; // use it as the offset which we want to delete
        foreach ($this->observers as $o) {
            if ($o == $observer) {
                array_splice($this->observers, $index);
            }
            $index++;
        }
    }

    public function notifyObserver() {
        foreach ($this->observers as $o) {
            $o->update($this);
        }
    }

}
