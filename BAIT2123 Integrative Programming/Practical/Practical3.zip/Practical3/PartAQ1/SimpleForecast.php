<?php

require_once 'Observer.php';
require_once 'Subject.php';
require_once 'WeatherData.php';
require_once 'DisplayElements.php';

class SimpleForecast implements Observer, DisplayElements {

    private $currentPressure;
    private $lastPressure;

    function __construct(WeatherData $w) {
        $this->currentPressure = $this->lastPressure = $w->getPressure();
    }

    public function Update(\Subject $subject) {
        $this->lastPressure = $this->currentPressure;
        $this->currentPressure = $subject->getPressure();
        $this->display();
    }

    public function display() {
        $msg = "<br/><b>Simple Forecast </b><br/>";
        if ($this->currentPressure > $this->lastPressure) {
            $msg .= "Improving weather on the way!<br/>";
        } else if ($this->currentPressure == $this->lastPressure) {
            $msg .= "More of the same<br/>";
        } else {
            $msg .= "Watch out for cooler, rainy weather<br/>";
        }
        echo $msg;
    }

}
