<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>PDO class CRUD statements</title>
        <style>
            table, th, td {
                border:1px solid black;
            }
        </style>
    </head>
    <body>
        <?php
//        $data = 'hello';
//        $result = shell_exec('C:\Users\zixua\OneDrive\Desktop\send.py ' . $data);
        Array
            (
            [name] => value
        );
//        echo $result;
        ?>

        <?php
        $host = 'localhost';
        $dbName = 'collegedb';
        $dbuser = 'root';
        $dbpassword = '';

        // set up DSN
        $dsn = "mysql:host=$host;dbname=$dbName";

        // Create connection
        try {
            $db = new PDO($dsn, $dbuser, $dbpassword);
        } catch (PDOException $ex) {
            echo "<p>ERROR: " . $ex->getMessage() . "</p>";
            exit;
        }

        // CRUD - Create 
        ###Hardcodes some value for insert statement
        $subCode = "BAIT2053";
        $title = "OOAD";
        $creditValue = 3;
        $yearOfStudy = 2;

        $query = "INSERT INTO Subjects(code, title, credit, yearOfStudy) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(1, $subCode);
        $stmt->bindParam(2, $title);
        $stmt->bindParam(3, $creditValue);
        $stmt->bindParam(4, $yearOfStudy);

        $stmt->execute();

        // CRUD - Update
        ###Hardcodes some value for update statement
        $title = "Change title now";
        $updateStmt = "UPDATE subjects SET title = ? WHERE code = ?";
        $db->prepare($updateStmt)->execute([$title, $subCode]);

        // CRUD - Delete
        $subCode = "BAIT2053"; ### hardcode code value to delete this record
        $deleteStmt = $db->prepare("DELETE FROM subjects WHERE code = ?");
        $deleteStmt->execute([$subCode]);
        $deleted = $deleteStmt->rowCount();
        echo "Deleted row : " . $deleted;

        // CRUD - Read (All records)
        $stmt = $db->query('SELECT * FROM subjects');
        echo "<h3>Records</h3><table>" . "<tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
        while ($row = $stmt->fetch()) {
            echo "<tr>"
            . "<td>" . $row['code'] . "</td>"
            . "<td>" . $row['title'] . "</td>"
            . "<td>" . $row['credit'] . "</td>"
            . "<td>" . $row['yearOfStudy'] . "</td>"
            . "</tr>";
        }
        echo "</table>";

        // CRUD - Read (prepared statement -- certain record(s))
        $code = "BM302"; ### hardcode code value to only view this record
        $stmt = $db->prepare('SELECT * FROM subjects WHERE code = ?');
        $stmt->execute([$code]);

        echo "<h3>Prepared Statement for read statement</h3><table>" . "<tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
        while ($row = $stmt->fetch()) {
            echo "<tr>"
            . "<td>" . $row['code'] . "</td>"
            . "<td>" . $row['title'] . "</td>"
            . "<td>" . $row['credit'] . "</td>"
            . "<td>" . $row['yearOfStudy'] . "</td>"
            . "</tr>";
        }
        echo "</table>";

        ###if only 1 records will return
        /*
         * $code = "BM302";
         * $stmt = $db->prepare('SELECT * FROM subjects WHERE code = ?');
         * $stmt->execute([$code]);
         * $user = $stmt->fetch();
         * var_dump($user);
         */

        // Close the connection
        $db = null;
        ?>
    </body>
</html>
