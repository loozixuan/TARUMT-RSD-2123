<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>PDO insert statement</title>
        <style>
            table, th, td {
                border:1px solid black;
            }

            .errMsg{
                color:red;
            }
        </style>
    </head>
    <body>
        <?php

        //Strip unnecessary characters & remove"\" & converts special characters to HTMO entities
        function prepareInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //Define variables
        $subCode = $title = $creditValue = $yearOfStudy = "";
        $errMsg = "";
        $isExist = false;

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            // Check all values has been entered
            if (empty($_POST["subjectCode"])) {
                $errMsg .= "<p class='errMsg'>&#9679; Subject code is required</p>";
            }

            if (empty($_POST["title"])) {
                $errMsg .= "<p class='errMsg'>&#9679; Title is required</p>";
            }

            if (empty($_POST["creditValue"])) {
                $errMsg .= "<p class='errMsg'>&#9679; Credit value for the subject title is required</p>";
            }

            if (empty($_POST["yearOfStudy"])) {
                $errMsg .= "<p class='errMsg'>&#9679; Year of study is required</p>";
            }

            if (strcmp($errMsg, "") != 0) {
                echo "<h3>Error Message(s) :</h3>" . $errMsg;
            } else { //If all value has been entered
                $subCode = prepareInput($_POST["subjectCode"]);
                $title = prepareInput($_POST["title"]);
                $creditValue = prepareInput($_POST["creditValue"]);
                $yearOfStudy = prepareInput($_POST["yearOfStudy"]);

                $host = 'localhost';
                $dbName = 'collegedb';
                $dbuser = 'root';
                $dbpassword = '';

                // set up DSN
                $dsn = "mysql:host=$host;dbname=$dbName";

                //Create connection
                try {
                    $db = new PDO($dsn, $dbuser, $dbpassword);
                } catch (PDOException $ex) {
                    echo "<p>ERROR: " . $ex->getMessage() . "</p>";
                    exit;
                }

                //Check if subject code exists in the db 
                $selectStmt = $db->query('SELECT code FROM subjects');
                while ($row = $selectStmt->fetch()) {
                    if ($subCode === $row['code']) {
                        $isExist = true;
                        break;
                    }
                }

                //If the $POST["subjectCode"] does not exists in db, proceeds next step
                if ($isExist === false) {
                    //Insert relevant data
                    $query = "INSERT INTO Subjects(code, title, credit, yearOfStudy) VALUES (?, ?, ?, ?)";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(1, $subCode, PDO::PARAM_STR);
                    $stmt->bindParam(2, $title, PDO::PARAM_STR);
                    $stmt->bindParam(3, $creditValue, PDO::PARAM_STR);
                    $stmt->bindParam(4, $yearOfStudy, PDO::PARAM_STR);

                    $stmt->execute();

                    // Display updated records
                    $stmt = $db->query('SELECT * FROM subjects');
                    echo "Updated Records: <br/><br/> <table>" . "<tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
                    $result = $stmt->rowCount();
                    if ($result > 0) {
                        while ($row = $stmt->fetch()) {
                            echo "<tr>"
                            . "<td>" . $row['code'] . "</td>"
                            . "<td>" . $row['title'] . "</td>"
                            . "<td>" . $row['credit'] . "</td>"
                            . "<td>" . $row['yearOfStudy'] . "</td>"
                            . "</tr>";
                        }
                        echo "</table>";
                    }

                    // Close the connection
                    $db = null;
                } else {
                    echo "<h3>Error Message :</h3> <p class='errMsg'>&#9679; The subject code has been registered. Please enter another subject code</p>";
                }
            }
        }
        ?>
    </body>
</html>
