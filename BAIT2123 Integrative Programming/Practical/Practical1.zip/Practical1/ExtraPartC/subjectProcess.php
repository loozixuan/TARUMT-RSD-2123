<style>
    table, th, td {
        border:1px solid black;
        text-align: center;
    }
</style>
<?php
require_once './DatabaseConnection.php';

$db = DatabaseConnection::getInstance();

function prepareInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST["add"])) {
    $errMsg = '';
    if (empty($_POST["subjectCode"])) {
        $errMsg .= "<p class='errMsg'>&#9679; Subject code is required</p>";
    }

    if (empty($_POST["title"])) {
        $errMsg .= "<p class='errMsg'>&#9679; Title is required</p>";
    }

    if (empty($_POST["creditValue"])) {
        $errMsg .= "<p class='errMsg'>&#9679; Credit value for the subject title is required</p>";
    }

    if (empty($_POST["yearOfStudy"])) {
        $errMsg .= "<p class='errMsg'>&#9679; Year of study is required</p>";
    }

    if (strcmp($errMsg, "") != 0) {
        echo "<h3>Error Message(s) :</h3>" . $errMsg;
    } else { //If all value has been entered
        $subCode = prepareInput($_POST["subjectCode"]);
        $title = prepareInput($_POST["title"]);
        $creditValue = prepareInput($_POST["creditValue"]);
        $yearOfStudy = prepareInput($_POST["yearOfStudy"]);

        $result = $db->addSubject($subCode, $title, $creditValue, $yearOfStudy);

        if ($result) {
            echo "<p>Record added successfully</p>";
        } else {
            echo "<p>Record not added successfully</p>";
        }
    }
    $db->closeConnection();
    echo "<a href='subjectForm.php'>Back to previous page</a>";
}

if (isset($_POST["search"])) {
    if (empty($_POST["subjectCode"])) {
        echo "<p class='errMsg'>&#9679; Please enter subject code before click the search button</p>";
    } else {
        $subCode = prepareInput($_POST["subjectCode"]);
        $result = $db->displaySubject($subCode);
        echo "<h2>Search Results:</h2>";
        if ($result == null) {
            echo "<p>Record not found</p>";
        } else {
            echo "<table><tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
            foreach ($result as $row) {
                echo "<tr><td>", $row['code'], "</td>";
                echo "<td>", $row['title'], "</td>";
                echo "<td>", $row['credit'], "</td>";
                echo "<td>", $row['yearOfStudy'], "</td></tr>";
            }
            echo "</table>";
        }
    }
    $db->closeConnection();
    echo "<a href='subjectForm.php'>Back to previous page</a>";
}

if (isset($_POST["delete"])) {
    if (empty($_POST["subjectCode"])) {
        echo "<p class='errMsg'>&#9679; Please enter subject code to be deleted</p>";
    } else {
        $subCode = prepareInput($_POST["subjectCode"]);
        $result = $db->deleteSubject($subCode);
        if ($result) {
            echo "<p>Record deleted successfully</p>";
        } else {
            echo "<p>Record not deleted successfully</p>";
        }
    }
    $db->closeConnection();
    echo "<a href='subjectForm.php'>Back to previous page</a>";
}

if (isset($_POST["update"])) {
    if (empty($_POST["subjectCode"])) {
        echo "<p class='errMsg'>&#9679; Please enter subject code to be updated</p>";
    } else {
        $subCode = prepareInput($_POST["subjectCode"]);
        $title = prepareInput($_POST["title"]);
        $creditValue = prepareInput($_POST["creditValue"]);
        $yearOfStudy = prepareInput($_POST["yearOfStudy"]);

        $result = $db->updateSubject($subCode, $title, $creditValue, $yearOfStudy);

        if ($result) {
            echo "<p>Record updated successfully</p>";
        } else {
            echo "<p>Record not updated successfully</p>";
        }
    }
    $db->closeConnection();
    echo "<a href='subjectForm.php'>Back to previous page</a>";
}

if (isset($_POST["showAll"])) {
    $result = $db->displayAllSubjects();

    echo "<h2>All records: </h2><table><tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
    foreach ($result as $row) {
        echo "<tr><td>", $row['code'], "</td>";
        echo "<td>", $row['title'], "</td>";
        echo "<td>", $row['credit'], "</td>";
        echo "<td>", $row['yearOfStudy'], "</td></tr>";
    }
    echo "</table>";
    echo "<a href='subjectForm.php'>Back to previous page</a>";
}
?>

