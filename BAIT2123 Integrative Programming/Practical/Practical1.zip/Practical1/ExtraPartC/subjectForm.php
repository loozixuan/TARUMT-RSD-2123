<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            table, th, td {
                border:1px solid black;
            }
        </style>
    </head>
    <?php
//    require_once './DatabaseConnection.php';
//    $db = DatabaseConnection::getInstance();
//
//    $stmt = $db->displayAllSubjets();
//    echo "<table><tr> <th>Code</th> <th>Title</th> <th>Credit</th> <th>Year of study</th> </tr>";
//    foreach ($stmt as $row) {
//        echo "<tr><td>", $row['code'], "</td>";
//        echo "<td>", $row['title'], "</td>";
//        echo "<td>", $row['credit'], "</td>";
//        echo "<td>", $row['yearOfStudy'], "</td></tr>";
//    }
//    echo "</table>";
    ?>
    <body>
        <h2><u>TAR UC Subject Form</u></h2>
        <form action="subjectProcess.php" method="post">
            Subject Code: <br/>
            <input type="text" name="subjectCode" /> <input type="submit" name="search" value="Search"/><br/><br/>

            Title: <br/>
            <input type="text" name="title" /><br/><br/>

            Credit Value: <br/>
            <input type="number" name="creditValue" /><br/><br/>

            Year of Study: <br/>
            <input type="number" name="yearOfStudy" /><br/><br/>

            <input type="submit" name="add" value="Add"/>
            <input type="submit" name="showAll" value="Show All"/>
            <input type="submit" name="update" value="Update"/>
            <input type="submit" name="delete" value="Delete"/>
        </form>
    </body>
</html>
