<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DatabaseConnection
 *
 * @author Loo Zi Xuan
 */
class DatabaseConnection {

    private static $instance = null;
    private $db;

    public function __construct() {
        $host = 'localhost';
        $dbName = 'collegedb';
        $dbuser = 'root';
        $dbpassword = '';
        $dsn = "mysql:host=$host;dbname=$dbName";

        try {
            $this->db = new PDO($dsn, $dbuser, $dbpassword);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $ex) {
            echo "<p>ERROR: " . $ex->getMessage() . "</p>";
            exit;
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new DatabaseConnection();
        }
        return self::$instance;
    }

    public function addSubject($code, $title, $creditValue, $year) {
        $stmt = $this->db->prepare("INSERT INTO subjects(code, title, credit, yearOfStudy) VALUES (?, ?, ?, ?)");
        $stmt->bindParam(1, $code, PDO::PARAM_STR);
        $stmt->bindParam(2, $title, PDO::PARAM_STR);
        $stmt->bindParam(3, $creditValue, PDO::PARAM_INT);
        $stmt->bindParam(4, $year, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt) {
            return true;
        } else {
            return false;
        }
    }

    public function deleteSubject($code) {
        $stmt = $this->db->prepare("DELETE FROM subjects WHERE code = ?");
        $stmt->bindParam(1, $code, PDO::PARAM_STR);

        $stmt->execute();
        if ($stmt) {
            return true;
        } else {
            return false;
        }
    }

    public function updateSubject($code, $title, $creditValue, $year) {
        $stmt = $this->db->prepare("UPDATE subjects SET title = ?, credit = ?, yearOfStudy = ? WHERE code = ?");
        $stmt->bindParam(1, $title, PDO::PARAM_STR);
        $stmt->bindParam(2, $creditValue, PDO::PARAM_INT);
        $stmt->bindParam(3, $year, PDO::PARAM_INT);
        $stmt->bindParam(4, $code, PDO::PARAM_STR);

        $stmt->execute();
        if ($stmt) {
            return true;
        } else {
            return false;
        }
    }

    public function displaySubject($code) {
        $stmt = $this->db->prepare('SELECT * FROM subjects WHERE code = ?');
        $stmt->execute([$code]);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function displayAllSubjects() {
        $stmt = $this->db->query('SELECT * FROM subjects');
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function closeConnection() {
        $this->db = null;
    }

}
