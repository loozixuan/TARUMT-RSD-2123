<?php

include_once 'Item.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FoodItem
 *
 * @author Loo Zi Xuan
 */
class FoodItem extends Item {

    private $unit;

    public function __construct($itemCode, $description, $price, $unit) {
        parent::__construct($itemCode, $description, $price);
        $this->unit = $unit;
    }

//    public function getUnit() {
//        return $this->unit;
//    }
//
//    public function setUnit($unit): void {
//        $this->unit = $unit;
//    }

    public function __set($name, $value) {
        if (property_exists($this, $name))
            $this->$name = $value;
        else
            parent::__set($name, $value);
    }

    public function __get($name) {
        if (property_exists($this, $name))
            return $this->$name;
        else
            return parent::__get($name);
    }

    public function calculatePrice() {
        return parent::getPrice() * $this->unit;
    }

    public function __toString() {
        return parent::__toString() . "Unit: $this->unit <br/>";
    }

    public function otherProperty() {
        return $this->unit;
    }

}
