<?php
include_once 'FoodItem.php';
include_once 'Stationery.php';
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Practical 1 Part B Q3</title>
        <style>
            table, th, td {
                border:1px solid black;
            }
        </style>
    </head>
    <body>
        <?php
        ## create polymorphic array
        $item = [
            new FoodItem("P1001", "Bread", 1.2, 12),
            new Stationery("P1002", "Correction Tape", 6.5, 25),
            new FoodItem("P1003", "Milk", 3.6, 12),
            new Stationery("P1004", "Pen", 6.6, 105),
        ];

        ## Output data
        echo "<h2>Product Information using toString() method</h2>";
        foreach ($item as $product) {
            print_r($product . "<br />"); // print_r to output the data in an array
        }

        ## Output data in a table form
        echo "<h2>Product Information in table format</h2>";
        echo "<table>";
        echo "<tr><th>Code</th>"
        . "<th>Description</th>"
        . "<th>Price</th>"
        . "<th>Unit/Weight</th>"
        . "</tr>";

        foreach ($item as $product) {
            echo "<tr><td> $product->itemCode</td>"
            . "<td>$product->description</td>"
            . " <td>$product->price</td>"
            . " <td>" . $product->otherProperty() . "</td>"
            . " </tr>";
        }
        echo "</table>";
        ?>
    </body>
</html>
