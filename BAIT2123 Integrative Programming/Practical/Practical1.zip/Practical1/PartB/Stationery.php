<?php

include_once 'Item.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Stationery
 *
 * @author Loo Zi Xuan
 */
class Stationery extends Item {

    private $weight;

    public function __construct($itemCode, $description, $price, $weight) {
        parent::__construct($itemCode, $description, $price);
        $this->weight = $weight;
    }

    public function getWeight() {
        return $this->weight;
    }

    public function setWeight($weight): void {
        $this->weight = $weight;
    }

    public function calculatePrice() {
        return parent::getPrice() * $this->weight;
    }

    public function __toString() {
        return parent::__toString() . "Weight: $this->weight <br/>";
    }

    public function otherProperty() {
        return $this->weight;
    }

}
