<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Item
 *
 * @author Loo Zi Xuan
 */
abstract class Item {

    private $itemCode, $description, $price;

    public function __construct($itemCode, $description, $price) {
        $this->itemCode = $itemCode;
        $this->description = $description;
        $this->price = $price;
    }

//    public function getItemCode() {
//        return $this->itemCode;
//    }
//
//    public function getDescription() {
//        return $this->description;
//    }
//
//    public function getPrice() {
//        return $this->price;
//    }
//
//    public function setItemCode($itemCode): void {
//        $this->itemCode = $itemCode;
//    }
//
//    public function setDescription($description): void {
//        $this->description = $description;
//    }
//
//    public function setPrice($price): void {
//        $this->price = $price;
//    }

    public function __set($name, $value) {
        $this->$name = $value;
    }

    public function __get($name) {
        return $this->$name;
    }

    public function __toString() {
        return "Item Code: $this->itemCode<br />"
                . "Description: $this->description<br >"
                . "Price: " . number_format($this->price, 2) . "<br />";
    }

    abstract public function otherProperty();

    abstract public function calculatePrice();
}
