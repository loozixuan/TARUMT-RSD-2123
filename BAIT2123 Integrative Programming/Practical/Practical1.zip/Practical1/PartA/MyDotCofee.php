<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Practical 1 Q2</title>
    </head>
    <body>
        <h2>MyDot Coffee</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            Number of bags : 
            <input type="number" name="quantity" min="1" 
                   value="<?php if (isset($_POST['quantity'])) echo $_POST['quantity']; ?>"
                   />

            <input type="submit" name="submit" value="Calculate"/>
        </form>

        <?php

        // Strip unnecessary characters & remove\ & converts special characters to HTMO entities
        function prepareInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        // define variables and constant
        $quantityOfBag = $totalPriceBeforeDiscount = $discountRate = $discountPrice = $totalCharge = "";
        define("BEAN_COST_PER_BAG", 5.5); // constant for each bag of beans costs

        if (isset($_POST['submit'])) {
            if (!empty($_POST["quantity"])) {
                $quantityOfBag = prepareInput($_POST["quantity"]);
                if ($quantityOfBag <= 25) {
                    $discountRate = 0;
                } else if ($quantityOfBag >= 25 && $quantityOfBag <= 50) {
                    $discountRate = 0.05;
                } else if ($quantityOfBag >= 50 && $quantityOfBag <= 100) {
                    $discountRate = 0.1;
                } else if ($quantityOfBag >= 100 && $quantityOfBag <= 150) {
                    $discountRate = 0.15;
                } else if ($quantityOfBag >= 150 && $quantityOfBag <= 200) {
                    $discountRate = 0.2;
                } else if ($quantityOfBag >= 200 && $quantityOfBag <= 300) {
                    $discountRate = 0.25;
                } else {
                    $discountRate = 0.25;
                }

                // Calculation 
                $totalPriceBeforeDiscount = BEAN_COST_PER_BAG * $quantityOfBag;
                $discountPrice = $totalPriceBeforeDiscount * $discountRate;
                $totalCharge = $totalPriceBeforeDiscount - $discountPrice;

                //Output the result
                echo "<br> Price for $quantityOfBag bags = RM $totalPriceBeforeDiscount <br>"
                . "Discount = RM $discountPrice <br>"
                . "Your total charge = RM $totalCharge <br>";

                // If total charge > 1000 get 1 free movie ticket
                if ($totalCharge > 1000) {
                    echo "<b>You will get 1 free movie ticket :)</b>";
                }
            } else {
                echo "The number of bags cannot be empty. Please enter the number of bag, thank you.";
            }
        }
        ?>
    </body>
</html>
