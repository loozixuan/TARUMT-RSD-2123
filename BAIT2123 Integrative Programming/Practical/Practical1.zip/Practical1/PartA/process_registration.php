<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Practical 1 Q1 (b)</title>
    </head>
    <body>
        <?php

        // Strip unnecessary characters & remove"\" & converts special characters to HTMO entities
        function prepareInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        // Define variables
        $name = $phoneNumber = $gender = "";
        $errMsg = $nameErr = $phoneNumberErr = "";

        // Validate and get relevant values from registration.html
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            ### .= (If have more then 1 error, we can append the .errMsg instead of replace it)
            if (empty($_POST["name"])) {
                $errMsg .= "Name is required<br/>";
            }

            if (empty($_POST["phonenumber"])) {
                $errMsg .= "Phonenumber is required<br/>";
            }

            if (empty($_POST["gender"])) {
                $errMsg .= "Gender is required<br/>";
            }

            if (strcmp($errMsg, "") != 0) {
                echo $errMsg;
            } else {
                $name = prepareInput($_POST["name"]);
                // Checks if the name field only contains uppercase and lowercase letters
                if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
                    $nameErr = "<span style='color:red'>Only uppercase and lowercase letters allowed for name field<span><br/>";
                    echo $nameErr;
                }

                // Checks if the mobile number only contains digits
                $phoneNumber = prepareInput($_POST["phonenumber"]);
                if (!preg_match("/^[0-9]{10,11}$/", $phoneNumber)) {
                    $phoneNumberErr = "<span style='color:red'>Only digits allowed for mobile number field<span><br/>";
                    echo $phoneNumberErr;
                }

                $gender = prepareInput($_POST["gender"]);

                if ($nameErr == "" && $phoneNumberErr == "") {
                    echo "<h3>Registration Successful</h3><b>";
                    if ($gender == "male")
                        echo "Mr $name <br>";
                    else
                        echo "Ms $name <br>";
                    echo "Mobile Number: $phoneNumber </b>";
                }
            }
        }
        ?>    
    </body>
</html>
