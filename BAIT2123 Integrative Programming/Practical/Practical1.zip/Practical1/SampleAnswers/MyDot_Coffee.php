<?php include 'discount.php' ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sample answer from tutor</title>
    </head>
    <body>
        <h2>MyDot Coffee</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            Number of bags : 
            <input type="text" name="quantity" value="<?php if (isset($_POST['quantity'])) echo $_POST['quantity']; ?>" />

            <input type="submit" name="submit" value="Calculate"/>
        </form>

        <?php
        define("UNIT_PRICE", 5.5);

        if (isset($_POST["quantity"])) {
            if (!filter_var($_POST["quantity"], FILTER_VALIDATE_INT) === false) {
                $quantity = $_POST["quantity"];
                $total = $quantity * UNIT_PRICE;
                echo "<br/> Price for $quantity bags = RM" . number_format($total, 2) . "<br/>";
                $discount = $total * number_format((getDiscountPrice($quantity) / 100), 2);
                echo "Discount =RM" . $discount . "<br/>";
                $total -= $discount;
                echo "Your total charge = RM" . number_format($total, 2) . "<br/>";
                if ($total > 1000) {
                    echo "<b>You will get 1 free movie ticket</b> &#128513";
                }
            } else {
                echo("<p>Only digit are allowed for number of bag</p>");
            }
        }
        ?>
    </body>
</html>
