<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $discount_Array = array(25 => 5, 50 => 10, 100 => 15, 200 => 25, 300 => 30);

        krsort($discount_Array);

        function getDiscountPrice($quantity) {
            global $discount_Array;
            foreach ($discount_Array as $key => $value) {
                if ($quantity >= $key) {
                    return $value;
                }
            }
        }
        ?>
    </body>
</html>
