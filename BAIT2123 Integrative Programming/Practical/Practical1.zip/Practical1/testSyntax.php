<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Practical Syntax Exercise Session 1</title>
    </head>
    <body>
        <?php
        $data = 'hello';
        $result = shell_exec('C:\Users\zixua\OneDrive\Desktop\send.py ' . $data);

        echo $result;
        ?>
        <?php
//        // display times 3 from 1 - 12
//        ## Method 1 : For Loop
//        for ($x = 1; $x <= 12; $x++) {
//            echo "$x x 3 = ", $x * 3, "<br/>";
//        }
//        ## Method 2 : While Loop
//        $number = 1;
//        while ($number <= 12) {
//            echo "$number x 3 = ", $number * 3, "<br/>";
//            $number++;
//        }
//
//        // Find area of circle of radius 2cm
//        define("PI", 3.14);
//        $radius = 2;
//        $areaOfCircle = PI * $radius * $radius;
//        echo "Area of circle for radius 2cm : ", $areaOfCircle;
//
//        // display product name and price 3 items
//        ### Single Dimension array 
//        $name = array("pencil", "pen", "correction tape");
//        $price = array(1.20, 4.50, 8.00);
//
//        echo "Product : <br/>";
//        for ($x = 0; $x < sizeof($name); $x++) {
//            echo "$name[$x] ", " RM $price[$x] <br/>";
//        }
//
//        ### Associative array
//        $items = array("prod1" => 34.00, "prod2" => 35.00, "prod3" => 36.00);
//
//        foreach ($items as $key => $value) {
//            echo "$key RM $value <br>";
//        }
//
//        ### Multidimensional array
//        $productTable = array(array('Code' => 'RT', 'Description' => 'Round Table', 'Price' => 20),
//            array('Code' => 'BC', 'Description' => 'Banquet Chair', 'Price' => 10));
//        for ($row = 0; $row < count($productTable); $row++) {
//            echo $productTable[$row]['Code'] . ', ' . $productTable[$row]['Description'] . ', ' . $productTable[$row]['Price'] . "<br/>";
//        }
//        
        ?>
    </body>
</html>
