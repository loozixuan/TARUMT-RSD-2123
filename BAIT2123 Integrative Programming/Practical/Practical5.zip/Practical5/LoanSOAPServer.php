<?php

require_once 'LoanCal.php';

$options = array("uri" => "http://localhost");
$server = new SoapServer(null, $options);
$server->setClass('LoanCal');
$server->handle();

