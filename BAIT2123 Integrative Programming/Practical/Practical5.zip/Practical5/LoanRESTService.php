<?php

header("Content-Type:application/json");
require "Loan.php";

if (!empty($_GET['amount']) && !empty($_GET['duration']) && !empty($_GET['rate'])) {
    $amount = $_GET['amount'];
    $duration = $_GET['duration'];
    $rate = $_GET['rate'];

    $loan = new Loan($rate, $duration, $amount);

    if (empty($loan)) {
        response(200, "Loan Not Found", NULL);
    } else {
        $monthlyPayment = $loan->getMonthlyPayment();
        $totalPayment = $loan->getTotalPayment();
        response(200, $monthlyPayment, $totalPayment);
    }
} else {
    response(400, "Invalid Request", NULL);
}

function response($status, $monthlyPayment, $totalPayment) {
    header("HTTP/1.1 " . $status);

    $response['status'] = $status;
    $response['monthlyPayment'] = $monthlyPayment;
    $response['totalPayment'] = $totalPayment;

    $json_response = json_encode($response);
    echo $json_response;
}

?>
