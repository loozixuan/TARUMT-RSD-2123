<?php

require_once 'lib/nusoap.php';
require_once 'LoanCal.php';

$server = new nusoap_server(); // Create a instance for nusoap server
$server->configureWSDL("LoanService", "uri:loan App"); // Configure WSDL file

$server->register(
        "LoanCal.calMonthlyPayment", // name of function
        array("rate" => "xsd:double", "duration" => "xsd:integer", "amount" => "xsd:double"), // inputs
        array("return" => "xsd:double"));

$server->register(
        "LoanCal.calTotalPayment", // name of function
        array("rate" => "xsd:double", "duration" => "xsd:integer", "amount" => "xsd:double"), // inputs
        array("return" => "xsd:double"));

$server->service(file_get_contents("php://input"));



