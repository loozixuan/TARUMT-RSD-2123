<?php

require_once 'Loan.php';

class LoanCal {

    // two remote methods
    function calMonthlyPayment($rate, $duration, $amount) {
        $loan = new Loan($rate, $duration, $amount);
        return $loan->getMonthlyPayment();
    }

    function calTotalPayment($rate, $duration, $amount) {
        $loan = new Loan($rate, $duration, $amount);
        return $loan->getTotalPayment();
    }

}
