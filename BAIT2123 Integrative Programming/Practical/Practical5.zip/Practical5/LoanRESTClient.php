<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>

    </head>
    <body>
        <form method="post">
            <table border="1">
                <tbody>
                    <tr>
                        <td>annual Interest Rate</td>
                        <td><input type="text" name="rate"/></td>
                    </tr>
                    <tr>
                        <td>number Of Years</td>
                        <td><input type="text" name="duration"/></td>
                    </tr>                   
                    <tr>
                        <td>loan Amount</td>
                        <td><input type="text" name="amount"/></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="submit"/></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </form>
        <?php
        if (isset($_POST['submit'])) {
            $amount = $_POST['amount'];
            $duration = $_POST['duration'];
            $rate = $_POST['rate'];

//            $url = "http://localhost/Practical5/LoanRESTService.php?rate=" . $rate . "&duration=" . $duration . "&amount=" . $amount;
            $url = "http://127.0.0.1:8000/api/admin/get-admins";
            $client = curl_init($url);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($client);

            $result = json_decode($response);
            var_dump($result);
//            echo "Monthly Payment : " . $result->monthlyPayment . "<br/>"
//            . "Total Payment : " . $result->totalPayment;
        }
        ?>
    </body>
</html>
