<?php
$options = array("location" => "http://localhost/Practical5/LoanSOAPServer.php",
    "uri" => "http://localhost");
?>

<html>
    <head>

    </head>
    <body>
        <form method="post">
            <table border="1">
                <tbody>
                    <tr>
                        <td>annualInterestRate</td>
                        <td><input type="text" name="rate"/></td>
                    </tr>
                    <tr>
                        <td>numberOfYears</td>
                        <td><input type="text" name="duration"/></td>
                    </tr>                   
                    <tr>
                        <td>loanAmount</td>
                        <td><input type="text" name="amount"/></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="submit"/></td>
                        <td></td>
                    </tr>

                </tbody>
            </table>
        </form>
    </body>
</html>

<?php
$rate = $year = $amount = 0;
if (isset($_POST['submit'])) {
    $rate = $_POST['rate'];
    $duration = $_POST['duration'];
    $amount = $_POST['amount'];
}
try {
    $client = new SoapClient(null, $options);

    $response_MonthlyPayment = $client->calMonthlyPayment($rate, $duration, $amount);
    $response_TotalPayment = $client->calTotalPayment($rate, $duration, $amount);

    echo "Monthly Payment : " . $response_MonthlyPayment . "<br/>"
    . "Total Payment : " . $response_TotalPayment;
} catch (SoapFault $ex) {
    var_dump($ex);
}
