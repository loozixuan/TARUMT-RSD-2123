<?php
require 'lib/nusoap.php';

$client = new nusoap_client("http://localhost/Practical5/LaonNuSOAPServer.php?wsdl"); // Create a instance for nusoap client
?>
<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
        <form method="post">
            <table border="1">
                <tbody>
                    <tr>
                        <td>annualInterestRate</td>
                        <td><input type="text" name="rate"/></td>
                    </tr>
                    <tr>
                        <td>numberOfYears</td>
                        <td><input type="text" name="duration"/></td>
                    </tr>                   
                    <tr>
                        <td>loanAmount</td>
                        <td><input type="text" name="amount"/></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="submit"/></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </form>
    </body>
</html>

<?php
$rate = $year = $amount = 0;
if (isset($_POST['submit'])) {
    $rate = $_POST['rate'];
    $duration = $_POST['duration'];
    $amount = $_POST['amount'];

    $response_MonthlyPayment = $client->call('LoanCal.calMonthlyPayment', array("rate" => $rate, "duration" => $duration, "amount" => $amount));
    $response_TotalPayment = $client->call('LoanCal.calTotalPayment', array("rate" => $rate, "duration" => $duration, "amount" => $amount));

    if (empty($response_MonthlyPayment)) {
        echo "no loan available<br/>";
    } else {
        echo "Monthly Payment : RM " . number_format((float) $response_MonthlyPayment, 2) . "<br/>";
    }

    if (empty($response_MonthlyPayment)) {
        echo "no loan available<br/>";
    } else {
        echo "Total Payment : RM " . number_format((float) $response_TotalPayment, 2) . "<br/>";
    }
}

